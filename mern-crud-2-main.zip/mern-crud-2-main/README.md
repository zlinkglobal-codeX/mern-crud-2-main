Source code from the video "Create a MERN CRUD App (2/6) - Creating a React frontend".
https://www.youtube.com/watch?v=jjuXRSb1UT8
